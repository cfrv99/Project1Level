﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using StepCourseProject.Areas.Client.Models;
using StepCourseProject.Entites;
using StepCourseProject.Repository.Abstract;
using StepCourseProject.Services.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace StepCourseProject.Areas.Client.Controllers
{
    [Area("Client")]
    [Authorize(Roles = "Client")]
    public class HomeController : Controller
    {
        private IPostService _postService;
        private UserManager<AppUser> _userManager;
        private ISkillRepo _skillRepo;
        private IBidService _bidService;

        public HomeController(IPostService postService, UserManager<AppUser> userManager, ISkillRepo skillRepo, IBidService _bidService)
        {
            _postService = postService;
            _userManager = userManager;
            _skillRepo = skillRepo;
            this._bidService = _bidService;
        }
        
        [HttpGet]
        public IActionResult CreateProject()
        {
            ViewBag.Skills = new SelectList(_skillRepo.GetSkills(), "Id", "SkillName");
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CreateProject(PostVM postVM)
        {
            var currentUserName = User.Identity.Name;
            var currentUser = await _userManager.FindByNameAsync(currentUserName);
            ViewBag.Skills = new SelectList(_skillRepo.GetSkills(), "Id", "SkillName");
            var post = new Post()
            {
                AppUserId = currentUser.Id,
                Id = postVM.Id,
                EndPrice = postVM.EndPrice,
                PostDate = postVM.PostDate,
                PostDeadLine = postVM.PostDeadLine,
                PostDescription = postVM.PostDescription,
                PostName = postVM.PostName,
                StartPrice = postVM.StartPrice,
                SkillId = postVM.SkillId,

            };

            if (ModelState.IsValid)
            {
                var skill = _skillRepo.GetSkill(post.SkillId);
                _postService.CreatePostFromClient(post, skill, currentUser);
                return RedirectToAction("Index");
            }
            return View(post);

        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var currentUserName = User.Identity.Name;
            var currentUser = await _userManager.FindByNameAsync(currentUserName);
            return View("List",_postService.GetYourPosts(currentUser).Where(x => x.HaveIsDoneBid == false));
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var currentUserName = User.Identity.Name;
            var currentUser = await _userManager.FindByNameAsync(currentUserName);
            var posts = _postService.GetYourPosts(currentUser);
            var post = posts.SingleOrDefault(i => i.Id == id);
            var postVM = new PostDetailsVM()
            {
                PostName = post.PostName,
                PostId = post.Id,
                Bids = post.Bids
                .Where(i => i.IsDone == false && i.Status== Entites.Enums.BidStatus.Accepted).ToList()
            };
            return View(postVM);
        }
        [HttpGet]
        public IActionResult DeletePost(int id)
        {
            _postService.DeletePost(id);
            return RedirectToAction("Index");
        }
    }
}
